import React from 'react'

function CardMap() {
  return (
    <div>Carsssssssssssssssp</div>
  )
}

export default CardMap